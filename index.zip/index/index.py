"""Windows and Linux"""

#pip install openai
#pip install linecache

"""Debian / raspberry pi"""

# sudo cp /boot/config.txt /boot/backupconfig.txt
#disable_overscan=1
#pip -m venv env
#pip install openai --break-system-packages
#nano GlowberryAI.py
# PASTE YOUR API KEY
#python3 GlowberryAI.py
#sicne you are poor you bought the free version which means that you have to restart it every 8 files.